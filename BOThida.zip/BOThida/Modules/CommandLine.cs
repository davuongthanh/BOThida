﻿using Discord.Commands;
using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BOThida.Modules
{
    class CommandLine : ModuleBase
    {
        //lệnh help
        [Command("help")]
        public async Task help()
        {
            try
            {
                await ReplyAsync("```fix\n" + "-Cú Pháp Tìm Kiếm Nhạc Trên Youtube Để Nghe-```\n" +

                    "```#music {song}\n" +
                    "#play {number song}\n"   +
                    "#pause,#skip,#resume```\n"  +

                    "```fix\n" + "-Cú Pháp Tìm Kiếm Thông Tin Liên minh Huyền Thoại-```\n" +

                    "```#ranklol {username} {sever}```\n" +

                    "```fix\n" + "-Cú Pháp Tìm Kiếm Thông Tin PLAYERUNKNOWN'S BATTLEGROUNDS-```\n" +

                    "```#rankpubg {username} {sever} {mode}```\n" );
            }
            catch { }
        }
        //Kiểm tra rank liên minh huyền thoại
        [Command("ranklol")]
        public async Task ranklol(string Name, string Region)
        {
            try
            {
                var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://" + Region + ".op.gg/summoner/userName=" + Name);

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    String _Html = streamReader.ReadToEnd();


                    //chuỗi rank solo
                    
                    string RankSolo = "unranked";
                    /*
                    string RankSoloPoint = "0 LP";
                    string RankSoloWin = "0 W";
                    string RankSoloLose = "0 L";
                    string RankSoloWinratio = "0 %";
                    */
                    //rank1:1
                    string RankSoloResult = "Chưa Có";
                    //rank5:5
                    //string Rank5vs5 = "Unranked";
                    //string Rank5vs5Points = "0 LP";
                    //string Rank5vs5Win = "0W";
                    //string Rank5vs5Lose = "0L";
                    //string Rank5vs5Winratio = "0%";
                    //string Rank5vs5Result = "Unranked";  

                    //rank3:3
                    //string Rank3vs3Result = "Unranked";

                    if (_Html.Contains("Ranked Solo"))
                    {
                        Match _RankSolo = Regex.Match(_Html, @"name=""description"" content=""(?<info>.+?)""/>", RegexOptions.IgnoreCase);
                        string[] arr = _RankSolo.Groups[1].Value.Split(new string[] { "%" }, StringSplitOptions.RemoveEmptyEntries);
                        RankSoloResult = arr[0] + "%";
                        
                        //rank Solo
                        Match _rank1vs1 = Regex.Match(_Html, @"<span class=""tierRank"">(?<rank1vs1>.+?)</span>", RegexOptions.IgnoreCase);
                        string[] arr2 = _rank1vs1.Groups[1].Value.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                        RankSolo = arr2[0];

                        /*
                        Match _rank1vs1_Points = Regex.Match(_Html, @"<span class=""LeaguePoints"">(?<rank1vs1_Points>.+?)</span>", RegexOptions.IgnoreCase);
                        RankSoloPoint = _rank1vs1_Points.Groups[1].Value.ToString();
                        Match _rank1vs1_win = Regex.Match(_Html, @"<span class=""wins"">(?<rank1vs1_win>.+?)</span>", RegexOptions.IgnoreCase);
                        RankSoloWin = _rank1vs1_win.Groups[1].Value.ToString();
                        Match _rank1vs1_lose = Regex.Match(_Html, @"<span class=""losses"">(?<rank1vs1_lose>.+?)</span>", RegexOptions.IgnoreCase);
                        RankSoloLose = _rank1vs1_lose.Groups[1].Value.ToString();
                        Match _rank1vs1_winratio = Regex.Match(_Html, @"<span class=""winratio"">(?<rank1vs1_winratio>.+?)</span>", RegexOptions.IgnoreCase);
                        RankSoloWinratio = _rank1vs1_winratio.Groups[1].Value.ToString();
                        */

                    }
                    //else if (_Html.Contains("Flex 5:5 Rank"))
                    //{

                    //    Match _rank5vs5 = Regex.Match(_Html, @"<div class=""TierRank"">(?<rank5vs5>.+?)</div>", RegexOptions.IgnoreCase);
                    //    Rank5vs5 = _rank5vs5.Groups[1].Value.ToString();
                    //    Match _rank5vs5_Points = Regex.Match(_Html, @"<div class=""leaguePoints"">(?<rank5vs5_Points>.+?)</div>", RegexOptions.IgnoreCase);
                    //    Rank5vs5Points = _rank5vs5_Points.Groups[1].Value.ToString();
                    //    Match _rank5vs5_win = Regex.Match(_Html, @"<span class=""wins"">(?<rank5vs5_win>.+?)</span>", RegexOptions.IgnoreCase);
                    //    Rank5vs5Win = _rank5vs5_win.Groups[1].Value.ToString();
                    //    Match _rank5vs5_lose = Regex.Match(_Html, @"<span class=""losses"">(?<rank5vs5_lose>.+?)</span>", RegexOptions.IgnoreCase);
                    //    Rank5vs5Lose = _rank5vs5_lose.Groups[1].Value.ToString();
                    //    Match _rank5vs5_winratio = Regex.Match(_Html, @"<span class=""winratio"">(?<rank5vs5_winratio>.+?)</span>", RegexOptions.IgnoreCase);
                    //    Rank5vs5Winratio = _rank5vs5_winratio.Groups[1].Value.ToString();

                    //    Rank5vs5Result = Rank5vs5 + " / " + Rank5vs5Points + " / " + Rank5vs5Win + " " + Rank5vs5Lose + " / " + Rank5vs5Winratio;

                    //}
                    //else if(_Html.Contains("Flex 3:3 Rank"))
                    //{
                    //rank 3 vs 3
                    //Match _rank3vs3 = Regex.Match(_Html, @"name=""description"" content=""(?<rank3vs3>.+?)""/>", RegexOptions.IgnoreCase);
                    //Match _rank3vs3_win = Regex.Match(_Html, @"name=""description"" content=""(?<rank3vs3_win>.+?)""/>", RegexOptions.IgnoreCase);
                    //Match _rank3vs3_lose = Regex.Match(_Html, @"name=""description"" content=""(?<rank3vs3_lose>.+?)""/>", RegexOptions.IgnoreCase);
                    //}






                    await ReplyAsync("```fix\n" + "Đây là thông tin của bạn " + Context.Message.Author.Username + " đang tìm. \n" + "Rank Đơn Đôi : " + RankSoloResult + "```");
                    await Context.Channel.SendFileAsync("RankLOLimage/" + RankSolo + ".png","");

                    //if (RankSoloResult.Contains("challenger"))
                    //{
                    //    await Context.Channel.SendFileAsync("RankLOLimage/challenger.png");
                    //}
                    //else if (RankSoloResult.Contains("master"))
                    //{
                    //    await Context.Channel.SendFileAsync("RankLOLimage/master.png");
                    //}
                    //else if (RankSoloResult.Contains("diamond"))
                    //{
                    //    await Context.Channel.SendFileAsync("RankLOLimage/diamond.png");
                    //}
                    //else if (RankSoloResult.Contains("platinum"))
                    //{
                    //    await Context.Channel.SendFileAsync("RankLOLimage/platinum.png");
                    //}
                    //else if (RankSoloResult.Contains("gold"))
                    //{
                    //    await Context.Channel.SendFileAsync("RankLOLimage/gold.png");
                    //}
                    //else if (RankSoloResult.Contains("silver"))
                    //{
                    //    await Context.Channel.SendFileAsync("RankLOLimage/silver.png");
                    //}
                    //else if (RankSoloResult.Contains("bronze"))
                    //{
                    //    await Context.Channel.SendFileAsync("RankLOLimage/bronze.png");
                    //}
                    //else if (RankSoloResult.Contains("unranked"))
                    //{
                    //    await Context.Channel.SendFileAsync("RankLOLimage/default.png");
                    //}
                    //await ReplyAsync("`Rank 5:5 : " + Rank5vs5Result + "`");
                }
            }
            catch
            {

            }

        }

        //Kiểm tra thông tin PLAYERUNKNOWN'S BATTLEGROUNDS
        [Command("rankpubg")]
        public async Task rankpubg(string Name, string Region, string Mode)
        {
            //data-u-user_id="
            try
            {
                var httpWebRequest_getid = (HttpWebRequest)WebRequest.Create("https://pubg.op.gg/user/" + Name + "?server=" + Region);

                var httpResponse = (HttpWebResponse)httpWebRequest_getid.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    String _Html_getid = streamReader.ReadToEnd();
                    Match _Getid = Regex.Match(_Html_getid, @"data-u-user_id=""(?<info>.+?)""", RegexOptions.IgnoreCase);
                    string _Userid = _Getid.Groups[1].Value.ToString();

                }
            }
            catch { }
        }
    }
}
